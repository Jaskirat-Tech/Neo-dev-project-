import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { FindFoodPage } from "@/components/find-food-page"

export default function FindFood() {
  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />
      <FindFoodPage />
      <Footer />
    </main>
  )
}
