import { Navbar } from "@/components/navbar"
import { Hero } from "@/components/hero"
import { HowItWorks } from "@/components/how-it-works"
import { FoodListings } from "@/components/food-listings"
import { ImpactTracker } from "@/components/impact-tracker"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />
      <Hero />
      <HowItWorks />
      <FoodListings />
      <ImpactTracker />
      <Footer />
    </main>
  )
}
