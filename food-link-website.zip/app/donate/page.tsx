import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { DonateForm } from "@/components/donate-form"

export default function DonatePage() {
  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />
      <DonateForm />
      <Footer />
    </main>
  )
}
