"use client"

import { useState } from "react"
import { Clock, MapPin, Search, Filter } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Image from "next/image"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function FindFoodPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedFilter, setSelectedFilter] = useState("all")

  const listings = [
    {
      id: 1,
      title: "Assorted Bagels (1 Dozen)",
      donor: "Downtown Bakery",
      distance: "0.5 miles",
      time: "Pickup by 6:00 PM",
      image: "/assorted-bagels.png",
      tags: ["Vegetarian", "Bakery"],
      description: "Fresh bagels from this morning. Plain, sesame, and everything flavors.",
    },
    {
      id: 2,
      title: "Fresh Rice & Curry Trays",
      donor: "Spice Garden",
      distance: "1.2 miles",
      time: "Pickup by 9:30 PM",
      image: "/flavorful-curry-rice.png",
      tags: ["Hot Meal", "Halal"],
      description: "Vegetable curry with basmati rice. Still hot and ready to eat.",
    },
    {
      id: 3,
      title: "Organic Bananas & Fruit",
      donor: "Sarah M.",
      distance: "0.3 miles",
      time: "Pickup anytime",
      image: "/bunch-of-bananas.png",
      tags: ["Fresh Produce", "Vegan"],
      description: "Ripe organic bananas and assorted fruit. Perfect condition.",
    },
    {
      id: 4,
      title: "Surplus Vegetable Soup",
      donor: "Community Center",
      distance: "2.0 miles",
      time: "Pickup by 5:00 PM",
      image: "/bowl-of-comforting-soup.png",
      tags: ["Homemade", "Frozen"],
      description: "Homemade vegetable soup, frozen in containers. Just reheat and enjoy.",
    },
    {
      id: 5,
      title: "Pizza Slices (8 slices)",
      donor: "Tony's Pizzeria",
      distance: "0.8 miles",
      time: "Pickup by 10:00 PM",
      image: "/fresh-pizza-slices.jpg",
      tags: ["Vegetarian", "Hot Meal"],
      description: "Margherita and veggie pizza slices from today.",
    },
    {
      id: 6,
      title: "Fresh Salad Boxes",
      donor: "Green Leaf Cafe",
      distance: "1.5 miles",
      time: "Pickup by 7:00 PM",
      image: "/fresh-green-salad.jpg",
      tags: ["Vegan", "Fresh Produce"],
      description: "Mixed green salads with dressing. Made fresh today.",
    },
  ]

  const filteredListings = listings.filter((listing) => {
    const matchesSearch =
      listing.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      listing.donor.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesFilter =
      selectedFilter === "all" || listing.tags.some((tag) => tag.toLowerCase() === selectedFilter.toLowerCase())
    return matchesSearch && matchesFilter
  })

  return (
    <section className="py-32 px-6 md:px-12 bg-secondary/20 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="mb-12">
          <h1 className="text-4xl md:text-5xl font-serif mb-4">Find Free Food</h1>
          <p className="text-muted-foreground text-lg">
            Browse available food listings near you and claim what you need.
          </p>
        </div>

        <div className="mb-8 flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              placeholder="Search for food items or donors..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 rounded-full"
            />
          </div>
          <Select value={selectedFilter} onValueChange={setSelectedFilter}>
            <SelectTrigger className="w-full md:w-[200px] rounded-full">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue placeholder="Filter" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Items</SelectItem>
              <SelectItem value="vegetarian">Vegetarian</SelectItem>
              <SelectItem value="vegan">Vegan</SelectItem>
              <SelectItem value="halal">Halal</SelectItem>
              <SelectItem value="hot meal">Hot Meal</SelectItem>
              <SelectItem value="fresh produce">Fresh Produce</SelectItem>
            </SelectContent>
          </Select>
          <Button
            variant="outline"
            className="rounded-full border-primary text-primary hover:bg-primary hover:text-primary-foreground bg-transparent"
          >
            View Map
          </Button>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredListings.map((item) => (
            <div
              key={item.id}
              className="group bg-background border border-border overflow-hidden hover:shadow-lg transition-all duration-300 flex flex-col"
            >
              <div className="relative aspect-[4/3] overflow-hidden">
                <Image
                  src={item.image || "/placeholder.svg"}
                  alt={item.title}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-3 left-3 flex gap-2 flex-wrap">
                  {item.tags.map((tag) => (
                    <Badge
                      key={tag}
                      variant="secondary"
                      className="bg-background/90 text-foreground rounded-sm font-normal backdrop-blur-sm"
                    >
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
              <div className="p-5 flex flex-col flex-grow">
                <h3 className="font-serif text-xl font-bold mb-1">{item.title}</h3>
                <p className="text-sm text-muted-foreground mb-2">{item.donor}</p>
                <p className="text-sm text-muted-foreground/80 mb-4 line-clamp-2">{item.description}</p>

                <div className="mt-auto space-y-3">
                  <div className="flex items-center text-sm text-muted-foreground">
                    <MapPin className="w-4 h-4 mr-2 text-primary" />
                    {item.distance}
                  </div>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Clock className="w-4 h-4 mr-2 text-primary" />
                    {item.time}
                  </div>

                  <Button className="w-full mt-4 rounded-full bg-primary text-primary-foreground hover:bg-primary/90">
                    Claim Listing
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredListings.length === 0 && (
          <div className="text-center py-16">
            <p className="text-muted-foreground text-lg">No listings found matching your search.</p>
          </div>
        )}
      </div>
    </section>
  )
}
