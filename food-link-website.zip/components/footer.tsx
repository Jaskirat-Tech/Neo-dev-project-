import Link from "next/link"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

export function Footer() {
  return (
    <footer className="bg-background border-t border-border pt-24 pb-12 px-6 md:px-12">
      <div className="max-w-7xl mx-auto grid md:grid-cols-4 gap-12 mb-24">
        <div className="md:col-span-2">
          <Link href="/" className="text-3xl font-serif font-bold tracking-tight text-primary block mb-6">
            FoodLink.
          </Link>
          <p className="text-xl max-w-md font-serif leading-relaxed text-muted-foreground">
            A community-driven platform dedicated to eliminating food waste and fighting hunger, one meal at a time.
          </p>
        </div>

        <div>
          <h4 className="font-bold mb-6 uppercase tracking-wider text-sm">Platform</h4>
          <ul className="space-y-4">
            <li>
              <Link href="#" className="text-muted-foreground hover:text-primary transition-colors">
                Browse Food
              </Link>
            </li>
            <li>
              <Link href="#" className="text-muted-foreground hover:text-primary transition-colors">
                Donate Food
              </Link>
            </li>
            <li>
              <Link href="#" className="text-muted-foreground hover:text-primary transition-colors">
                Impact Report
              </Link>
            </li>
            <li>
              <Link href="#" className="text-muted-foreground hover:text-primary transition-colors">
                Community Guidelines
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h4 className="font-bold mb-6 uppercase tracking-wider text-sm">Newsletter</h4>
          <p className="text-muted-foreground mb-4 text-sm">Stay updated on our mission and local impact.</p>
          <div className="flex gap-2">
            <Input placeholder="Enter your email" className="rounded-none border-primary bg-transparent" />
            <Button className="rounded-none bg-primary text-primary-foreground">Join</Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto border-t border-border pt-8 flex flex-col md:flex-row justify-between items-center text-sm text-muted-foreground">
        <p>&copy; 2025 FoodLink. All rights reserved.</p>
        <div className="flex gap-6 mt-4 md:mt-0">
          <Link href="#">Privacy</Link>
          <Link href="#">Terms</Link>
          <Link href="#">Cookies</Link>
        </div>
      </div>
    </footer>
  )
}
