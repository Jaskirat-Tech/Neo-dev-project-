import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import Link from "next/link"

export function Hero() {
  return (
    <section className="relative min-h-[80vh] flex items-center pt-20 pb-32 px-6 md:px-12 overflow-hidden">
      <div className="max-w-7xl mx-auto w-full grid md:grid-cols-2 gap-16 items-center">
        <div className="space-y-8 relative z-10">
          <div className="inline-block px-4 py-1.5 border border-primary/30 rounded-full text-sm font-medium text-primary uppercase tracking-wider bg-primary/5">
            Zero Hunger Initiative
          </div>
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-serif leading-[1.1] text-foreground">
            Share food, <br />
            <span className="italic">save the planet.</span>
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-md leading-relaxed">
            Connecting extra food from restaurants and homes to the people who need it most. Join the movement to end
            food waste.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 pt-4">
            <Link href="/find-food">
              <Button
                size="lg"
                className="rounded-full text-lg px-8 py-6 bg-primary hover:bg-primary/90 w-full sm:w-auto"
              >
                Find Free Food
              </Button>
            </Link>
            <Link href="/donate">
              <Button
                size="lg"
                variant="outline"
                className="rounded-full text-lg px-8 py-6 border-primary text-primary hover:bg-primary/5 group bg-transparent w-full sm:w-auto"
              >
                Donate Food <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
          </div>
        </div>

        <div className="relative h-[500px] w-full hidden md:block">
          {/* Abstract composition resembling the 'Casa Portufornia' collage style */}
          <div className="absolute top-0 right-0 w-4/5 h-full bg-secondary/50 rounded-t-full overflow-hidden">
            <Image
              src="/fresh-bread-and-vegetables-aesthetic.jpg"
              alt="Fresh food donation"
              fill
              className="object-cover opacity-90 hover:scale-105 transition-transform duration-700"
            />
          </div>
          <div className="absolute bottom-10 left-0 w-1/2 h-3/5 border-2 border-primary bg-background p-2 z-20">
            <div className="w-full h-full relative overflow-hidden">
              <Image src="/happy-community-meal.jpg" alt="Community sharing food" fill className="object-cover" />
            </div>
          </div>
          <div className="absolute top-20 left-10 w-24 h-24 bg-primary rounded-full flex items-center justify-center text-primary-foreground z-30 animate-in fade-in zoom-in duration-1000 delay-500">
            <span className="font-serif text-xl font-bold">-2kg CO2</span>
          </div>
        </div>
      </div>
    </section>
  )
}
