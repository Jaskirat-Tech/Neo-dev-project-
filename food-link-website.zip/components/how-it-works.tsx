export function HowItWorks() {
  const steps = [
    {
      number: "01",
      title: "Post a Listing",
      description: "Donors take a photo and add details like quantity, expiry time, and pickup location.",
      role: "For Donors",
    },
    {
      number: "02",
      title: "Claim Food",
      description: "People nearby browse the map or list to find food they need and request a pickup.",
      role: "For Receivers",
    },
    {
      number: "03",
      title: "Meet & Pickup",
      description: "Coordinate via instant chat and meet at the designated spot to rescue the food.",
      role: "Community",
    },
  ]

  return (
    <section id="how-it-works" className="py-24 border-t border-border px-6 md:px-12">
      <div className="max-w-7xl mx-auto">
        <div className="mb-20">
          <h2 className="text-4xl md:text-6xl font-serif mb-6">
            Simple steps to <br />
            make a difference.
          </h2>
          <p className="text-muted-foreground max-w-xl text-lg">
            Whether you have extra food to give or are looking for a meal, our platform makes the connection seamless
            and dignified.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-12 relative">
          {/* Connecting line for desktop */}
          <div className="hidden md:block absolute top-12 left-0 w-full h-px bg-border -z-10"></div>

          {steps.map((step, index) => (
            <div key={index} className="bg-background pt-4 pr-4 group">
              <div className="text-8xl font-serif text-primary/20 mb-6 group-hover:text-primary/40 transition-colors">
                {step.number}
              </div>
              <div className="inline-block px-3 py-1 mb-4 text-xs font-semibold border border-primary rounded-full text-primary">
                {step.role}
              </div>
              <h3 className="text-2xl font-serif font-bold mb-3">{step.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
