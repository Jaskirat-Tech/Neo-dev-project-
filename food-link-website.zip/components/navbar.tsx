import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Menu } from "lucide-react"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export function Navbar() {
  return (
    <nav className="border-b border-border py-4 px-6 md:px-12 sticky top-0 z-50 bg-background/95 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <Link href="/" className="text-3xl font-serif font-bold tracking-tight text-primary">
          FoodLink.
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center gap-8">
          <Link href="#how-it-works" className="text-sm font-medium hover:text-primary transition-colors">
            How it Works
          </Link>
          <Link href="#listings" className="text-sm font-medium hover:text-primary transition-colors">
            Find Food
          </Link>
          <Link href="#impact" className="text-sm font-medium hover:text-primary transition-colors">
            Our Impact
          </Link>
          <div className="flex items-center gap-4 ml-4">
            <Button
              variant="outline"
              className="rounded-full border-primary text-primary hover:bg-primary hover:text-primary-foreground px-6 bg-transparent"
            >
              Log In
            </Button>
            <Button className="rounded-full bg-primary text-primary-foreground hover:bg-primary/90 px-6">
              Donate Food
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        <div className="md:hidden">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent>
              <div className="flex flex-col gap-6 mt-10">
                <Link href="#how-it-works" className="text-xl font-serif hover:text-primary">
                  How it Works
                </Link>
                <Link href="#listings" className="text-xl font-serif hover:text-primary">
                  Find Food
                </Link>
                <Link href="#impact" className="text-xl font-serif hover:text-primary">
                  Our Impact
                </Link>
                <hr className="border-border" />
                <Button className="w-full rounded-full bg-primary text-primary-foreground">Donate Food</Button>
                <Button variant="outline" className="w-full rounded-full border-primary text-primary bg-transparent">
                  Log In
                </Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  )
}
