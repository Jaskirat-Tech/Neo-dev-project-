export function ImpactTracker() {
  return (
    <section id="impact" className="py-24 px-6 md:px-12 bg-primary text-primary-foreground">
      <div className="max-w-7xl mx-auto text-center">
        <h2 className="text-4xl md:text-6xl font-serif mb-16">Our Collective Impact</h2>

        <div className="grid md:grid-cols-3 gap-12 md:divide-x divide-primary-foreground/20">
          <div className="p-4">
            <div className="text-6xl md:text-7xl font-serif font-bold mb-2">12.5k</div>
            <div className="text-lg uppercase tracking-widest opacity-80">Meals Provided</div>
          </div>
          <div className="p-4">
            <div className="text-6xl md:text-7xl font-serif font-bold mb-2">4.2T</div>
            <div className="text-lg uppercase tracking-widest opacity-80">Food Saved</div>
          </div>
          <div className="p-4">
            <div className="text-6xl md:text-7xl font-serif font-bold mb-2">8.9T</div>
            <div className="text-lg uppercase tracking-widest opacity-80">CO2 Prevented</div>
          </div>
        </div>

        <div className="mt-20 p-8 border border-primary-foreground/30 inline-block max-w-2xl">
          <p className="text-xl md:text-2xl font-serif italic">
            "FoodLink has transformed how our restaurant handles surplus. Instead of the bin, our food goes to neighbors
            who appreciate it."
          </p>
          <div className="mt-6 text-sm font-bold uppercase tracking-widest">— Maria, The Local Kitchen</div>
        </div>
      </div>
    </section>
  )
}
