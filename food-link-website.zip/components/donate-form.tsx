"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { ArrowLeft, Upload, CheckCircle2 } from "lucide-react"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"

export function DonateForm() {
  const [submitted, setSubmitted] = useState(false)
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    donor: "",
    quantity: "",
    pickupTime: "",
    address: "",
    dietary: [] as string[],
  })

  const dietaryOptions = ["Vegetarian", "Vegan", "Halal", "Kosher", "Gluten-Free", "Nut-Free"]

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("[v0] Form submitted:", formData)
    setSubmitted(true)
    setTimeout(() => setSubmitted(false), 3000)
  }

  const toggleDietary = (option: string) => {
    setFormData((prev) => ({
      ...prev,
      dietary: prev.dietary.includes(option) ? prev.dietary.filter((d) => d !== option) : [...prev.dietary, option],
    }))
  }

  return (
    <section className="py-32 px-6 md:px-12 bg-secondary/20">
      <div className="max-w-3xl mx-auto">
        <Link href="/" className="inline-flex items-center text-primary hover:text-primary/80 mb-8 transition-colors">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Home
        </Link>

        <div className="bg-background border border-border p-8 md:p-12">
          <div className="mb-8">
            <h1 className="text-4xl md:text-5xl font-serif mb-4">Donate Food</h1>
            <p className="text-muted-foreground text-lg">
              Share your extra food with the community. Fill out the details below to create a listing.
            </p>
          </div>

          {submitted && (
            <div className="mb-6 p-4 bg-primary/10 border border-primary rounded-sm flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
              <CheckCircle2 className="w-5 h-5 text-primary" />
              <p className="text-primary font-medium">Your food donation has been posted successfully!</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="title">Food Title *</Label>
              <Input
                id="title"
                placeholder="e.g., Fresh Bagels, Vegetable Soup"
                required
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="rounded-sm"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description *</Label>
              <Textarea
                id="description"
                placeholder="Describe the food, quantity, and any special notes..."
                required
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="min-h-32 rounded-sm"
              />
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="donor">Your Name or Business *</Label>
                <Input
                  id="donor"
                  placeholder="e.g., Downtown Bakery"
                  required
                  value={formData.donor}
                  onChange={(e) => setFormData({ ...formData, donor: e.target.value })}
                  className="rounded-sm"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="quantity">Quantity/Servings</Label>
                <Input
                  id="quantity"
                  placeholder="e.g., 12 items, 4 servings"
                  value={formData.quantity}
                  onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                  className="rounded-sm"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="pickupTime">Pickup Time *</Label>
              <Input
                id="pickupTime"
                type="datetime-local"
                required
                value={formData.pickupTime}
                onChange={(e) => setFormData({ ...formData, pickupTime: e.target.value })}
                className="rounded-sm"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="address">Pickup Address *</Label>
              <Input
                id="address"
                placeholder="Full address for pickup"
                required
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                className="rounded-sm"
              />
            </div>

            <div className="space-y-3">
              <Label>Dietary Tags</Label>
              <div className="flex flex-wrap gap-2">
                {dietaryOptions.map((option) => (
                  <Badge
                    key={option}
                    variant={formData.dietary.includes(option) ? "default" : "outline"}
                    className="cursor-pointer rounded-sm transition-colors"
                    onClick={() => toggleDietary(option)}
                  >
                    {option}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="space-y-3 pt-2">
              <Label htmlFor="image" className="flex items-center gap-2">
                <Upload className="w-4 h-4" />
                Upload Photo (Optional)
              </Label>
              <Input id="image" type="file" accept="image/*" className="rounded-sm" />
              <p className="text-sm text-muted-foreground">Add a photo to help others identify your donation</p>
            </div>

            <div className="pt-6 flex gap-4">
              <Button type="submit" className="rounded-full px-8 bg-primary hover:bg-primary/90 flex-1">
                Post Donation
              </Button>
              <Button type="button" variant="outline" className="rounded-full px-8 border-primary bg-transparent">
                Preview
              </Button>
            </div>
          </form>
        </div>
      </div>
    </section>
  )
}
