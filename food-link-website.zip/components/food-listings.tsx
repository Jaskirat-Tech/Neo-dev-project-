import { Clock, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import { Badge } from "@/components/ui/badge"

export function FoodListings() {
  const listings = [
    {
      id: 1,
      title: "Assorted Bagels (1 Dozen)",
      donor: "Downtown Bakery",
      distance: "0.5 miles",
      time: "Pickup by 6:00 PM",
      image: "/assorted-bagels.png",
      tags: ["Vegetarian", "Bakery"],
    },
    {
      id: 2,
      title: "Fresh Rice & Curry Trays",
      donor: "Spice Garden",
      distance: "1.2 miles",
      time: "Pickup by 9:30 PM",
      image: "/flavorful-curry-rice.png",
      tags: ["Hot Meal", "Halal"],
    },
    {
      id: 3,
      title: "Organic Bananas & Fruit",
      donor: "Sarah M.",
      distance: "0.3 miles",
      time: "Pickup anytime",
      image: "/bunch-of-bananas.png",
      tags: ["Fresh Produce", "Vegan"],
    },
    {
      id: 4,
      title: "Surplus Vegetable Soup",
      donor: "Community Center",
      distance: "2.0 miles",
      time: "Pickup by 5:00 PM",
      image: "/bowl-of-comforting-soup.png",
      tags: ["Homemade", "Frozen"],
    },
  ]

  return (
    <section id="listings" className="py-24 bg-secondary/30 px-6 md:px-12">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
          <div>
            <h2 className="text-4xl md:text-5xl font-serif mb-4">Available Near You</h2>
            <p className="text-muted-foreground">Real-time listings from your local community.</p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              className="rounded-full border-primary text-primary hover:bg-primary hover:text-primary-foreground bg-transparent"
            >
              View Map
            </Button>
            <Button className="rounded-full bg-primary text-primary-foreground hover:bg-primary/90">
              Filter Results
            </Button>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {listings.map((item) => (
            <div
              key={item.id}
              className="group bg-background border border-border rounded-none overflow-hidden hover:shadow-lg transition-all duration-300 flex flex-col"
            >
              <div className="relative aspect-[4/3] overflow-hidden">
                <Image
                  src={item.image || "/placeholder.svg"}
                  alt={item.title}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-3 left-3 flex gap-2">
                  {item.tags.map((tag) => (
                    <Badge
                      key={tag}
                      variant="secondary"
                      className="bg-background/90 text-foreground rounded-sm font-normal backdrop-blur-sm"
                    >
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
              <div className="p-5 flex flex-col flex-grow">
                <h3 className="font-serif text-xl font-bold mb-1">{item.title}</h3>
                <p className="text-sm text-muted-foreground mb-4">{item.donor}</p>

                <div className="mt-auto space-y-3">
                  <div className="flex items-center text-sm text-muted-foreground">
                    <MapPin className="w-4 h-4 mr-2 text-primary" />
                    {item.distance}
                  </div>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Clock className="w-4 h-4 mr-2 text-primary" />
                    {item.time}
                  </div>

                  <Button className="w-full mt-4 rounded-full bg-primary text-primary-foreground hover:bg-primary/90 group-hover:translate-y-0">
                    Claim Listing
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
